#!/bin/sh
sudo docker kill zuul-gateway
sudo docker rm zuul-gateway
sudo docker build -t zuul-gateway .
sudo docker run -d --rm --name zuul-gateway -p 7020:7020 zuul-gateway