#!/bin/sh
sudo docker kill sample-service
sudo docker rm sample-service
sudo docker build -t sample-service .
sudo docker run -d --rm --name sample-service -p 8080:8080 sample-service
sudo docker run -d --rm --name sample-service -p 8081:8080 sample-service
